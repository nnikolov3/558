# README

- The bin folder is not comprised with real binaries these are sym links to
  python scripts
