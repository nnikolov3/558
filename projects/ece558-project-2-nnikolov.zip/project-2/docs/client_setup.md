# Setting up the client

- Using the mosquitto_sub utility
    mqttv311 specifies the version of the protocol
    `mosquitto_sub -V mqttv311 -t <topic to subscribe to>`



